import logo from './logo.svg';
import './App.css';
import Input from './Input';

function App() {
  return (
    <div className="App">
      <Input/>
      
    </div>
  );
}

export default App;
